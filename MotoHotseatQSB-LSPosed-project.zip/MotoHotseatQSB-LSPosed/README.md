# Moto Hotseat Google Search Bar — LSPosed module

This project is intended for Motorola Launcher package `com.motorola.launcher3`. It uses the legacy Xposed resource-hook API (supported by LSPosed) to replace these boolean resources with `true`:

- `config_enable_hotseat_qsb`
- `config_hotseat_qsb_default_value`

These resources were observed in the supplied Moto Launcher APK and the device's active product overlay reported both values as `false`. This is a targeted resource override, not an APK patch or a guarantee that every Moto Launcher build will render the widget.

## Install/use
1. Build the APK (or download the CI artifact from GitHub Actions).
2. Install the APK.
3. In LSPosed, enable the module and set scope to **Moto 应用启动器 / `com.motorola.launcher3`**.
4. Reboot, or force-stop the launcher and reopen Home.
5. Check LSPosed logs for `MotoHotseatQSB`.

If the search bar still does not appear, this means the resource toggle alone is insufficient on this particular launcher build; the next step is a method-level hook into `QsbContainerView`/Hotseat, which requires examining the matching launcher implementation.

## Build
Open this folder in Android Studio with JDK 17 and Android SDK 35, or use the included GitHub Actions workflow. The Xposed API is a compile-only dependency; LSPosed provides it at runtime.
