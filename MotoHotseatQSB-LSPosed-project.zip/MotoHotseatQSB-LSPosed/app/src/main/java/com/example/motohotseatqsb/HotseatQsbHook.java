package com.example.motohotseatqsb;

import de.robv.android.xposed.IXposedHookInitPackageResources;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_InitPackageResources;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;

/**
 * Enables the two known Moto Launcher resource flags that control the Hotseat QSB.
 * Enable this module's scope for com.motorola.launcher3 in LSPosed, then force-stop
 * or reboot the launcher. The launcher must itself support rendering the QSB.
 */
public final class HotseatQsbHook implements IXposedHookInitPackageResources, IXposedHookLoadPackage {
    private static final String TARGET = "com.motorola.launcher3";

    @Override
    public void handleInitPackageResources(XC_InitPackageResources.InitPackageResourcesParam resparam) {
        if (!TARGET.equals(resparam.packageName)) return;
        try {
            resparam.res.setReplacement(TARGET, "bool", "config_enable_hotseat_qsb", true);
            XposedBridge.log("MotoHotseatQSB: replaced config_enable_hotseat_qsb=true");
        } catch (Throwable t) {
            XposedBridge.log("MotoHotseatQSB: failed replacing config_enable_hotseat_qsb: " + t);
        }
        try {
            resparam.res.setReplacement(TARGET, "bool", "config_hotseat_qsb_default_value", true);
            XposedBridge.log("MotoHotseatQSB: replaced config_hotseat_qsb_default_value=true");
        } catch (Throwable t) {
            XposedBridge.log("MotoHotseatQSB: failed replacing config_hotseat_qsb_default_value: " + t);
        }
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (TARGET.equals(lpparam.packageName)) {
            XposedBridge.log("MotoHotseatQSB: loaded into Motorola Launcher process");
        }
    }
}
